
class RecipeManager {
  constructor(userConfig) {
    this.userConfig_ = userConfig;

    this.wrapper_ = document.querySelector('section.recipe-wrapper .recipes');
    this.recipesById_ = {};
    this.browserEnv_ = new BrowserEnv();

    this.importManager_ = new RecipeImporter(document.body);
  }

  initialize() {
    if (this.userConfig_.paidPro) {
      this.importManager_.addOnDropHandler(recipe => this.handleRecipeImport_(recipe));
      this.importManager_.addOnErrorHandler(({err, file}) => this.handleError_(err));

      document
          .querySelector('.btn-new-recipe')
          .addEventListener('click', this.handleNewRecipe_.bind(this));
      document
          .querySelector('.btn-clear-all')
          .addEventListener('click', this.handleDeleteAll_.bind(this));

      this.fetchRecipes_()
          .then(recipes => this.renderRecipes_(recipes))
          .catch(err => this.handleError_(err));
    } else {
      document
          .querySelector('.dropzone-mask')
          .classList.add('hidden');

      document
          .querySelector('.btn-new-recipe')
          .setAttribute('disabled', 'disabled');
      document
          .querySelector('.btn-clear-all')
          .setAttribute('disabled', 'disabled');

      const message = (_TCAP_CONFIG.paidOnly && this.userConfig_.requiresPaid)
          ? `You currently have no recipes. <a class="alert-link" href="/activate.html">Activate Table Capture</a> to create some.`
          : `You currently have no recipes. <a class="alert-link" href="/upgrade.html">Upgrade to Pro</a> to create some.`;
      this.wrapper_.innerHTML = '';
      this.wrapper_.appendChild(createAlertPaneWithHTML(message, 'warning'));
    }
  }

  setRecipes(recipes) {
    this.recipesById_ = {};
    recipes.forEach(r => this.recipesById_[r.id] = r);
  }

  isWithoutActiveRecipes() {
    const recipes = Object.values(this.recipesById_);
    return recipes.filter(r => r.status === 'active').length === 0;
  }

  handleDeleteAll_() {
    this.browserEnv_
        .deleteWorld('_recipe_world')
        .then(() => this.browserEnv_.getSyncStorageApi().removeP('recipes'))
        .then(() => this.renderRecipes_([]))
        .catch(err => this.handleError_(err));
  }

  fetchRecipes_() {
    return this.browserEnv_
        .getWorlds(['_recipe_world'], {recipes: []})
        .then(optionsValues => {
          return Promise.resolve(optionsValues.recipes.filter(r => r.status == 'active'));
        });
  }

  handleNewRecipe_() {
    if (this.isWithoutActiveRecipes()) {
      this.wrapper_.innerHTML = '';
    }
    this.renderEditForm_({id: Math.random().toString(36).slice(2)}, true);
  }

  handleRecipeImport_(recipe) {
    if (this.isWithoutActiveRecipes()) {
      this.wrapper_.innerHTML = '';
    }
    recipe.id = Math.random().toString(36).slice(2);
    this.renderEditForm_(recipe, true);
  }

  renderNoRecipes_() {
    this.wrapper_.innerHTML = '';
    this.wrapper_.appendChild(createAlertPane('You currently have no recipes', 'success'));
  }

  renderRecipes_(recipes) {
    this.setRecipes(recipes);
    if (this.isWithoutActiveRecipes()) {
      return this.renderNoRecipes_();
    }
    this.wrapper_.innerHTML = '';
    recipes.forEach(recipe => this.renderEditForm_(recipe));
  }

  renderEditForm_(recipe, expand=false) {
    const timestamp = (recipe.updated)
        ? new Date(recipe.updated)
        : new Date();

// NOTE(gmike): Deliberately fugly.
const defaultBody = `
  const rows = [];
  // TODO(you): Figure out how to turn this element into an array of arrays.
  return rows;
`;
const defaultRowProviderBody = `
  return [];
`;

    const form = document.createElement('form');
    form.className = `collapsed ${recipe.disabled && "form-disabled"}`;
    form.innerHTML = `
      <div class="collapsed-header">
        <div>
          <span>${recipe.name || 'None'}</span>
          <small>${timestamp.toLocaleDateString()}</small>
        </div>
        <div>
          <input type="button"
              class="btn btn-default btn-edit"
              value="Edit" />
          <input type="button" class="btn btn-default btn-export" value="Export" />
          <input
              type="button"
              class="btn btn-default btn-toggle-status"
              value="${recipe.disabled ? "Enable" : "Disable"}" />
        </div>
      </div>
      <div class="form-group">
        <label for="recipe-name">Recipe name</label>
        <input
            type="text"
            class="form-control recipe-name"
            name="recipe-name"
            id="recipe-name"
            value="${recipe.name || ''}"
            placeholder="Name" />
      </div>
      <div class="form-group">
        <label for="recipe-desc">Description</label>
        <input
            type="text"
            class="form-control recipe-desc"
            name="recipe-desc"
            id="recipe-desc"
            value="${recipe.description || ''}"
            placeholder="Description" />
      </div>
      <div class="form-group">
        <label for="recipe-url-example">Recipe URL Example</label>
        <input
            type="text"
            class="form-control recipe-url-example"
            name="recipe-url-example"
            id="recipe-url-example"
            value="${recipe.urlExample || ''}"
            placeholder="An example url" />
      </div>
      <div class="form-group">
        <label for="recipe-url-regex">Recipe URL Regex</label>
        <input
            type="text"
            class="form-control recipe-url-regex"
            name="recipe-url-regex"
            id="recipe-url-regex"
            value="${recipe.urlRegex || ''}"
            placeholder="A regular expression to match the above URL" />
      </div>
      <div class="form-group">
        <label for="recipe-selector">Table element selector</label>
        <input
            type="text"
            class="form-control recipe-selector"
            name="recipe-selector"
            id="recipe-selector"
            value="${recipe.selector || ''}"
            placeholder="The DOM selector" />
      </div>
      <div class="form-group">
        <label for="recipe-fn">Function: Element &rarr; Array of Arrays</label>
        <p class="context">
          This function will be called with the table element retrieved using the DOM selector above. Don't change the function signature.
        </p>
<pre contentEditable="true" class="recipe-fn" spellcheck="false">
function element2DataTable(element) {${recipe.fn || defaultBody}}
</pre>
      </div>
      <div class="form-group">
        <label for="recipe-rowprovider-fn">Function: Row Element to Array</label>
        <p class="context">
          This is function is completely optional. It'll be called with a table row when the table is a Dynamic Table. Don't change the function signature.
        </p>
<pre contentEditable="true" class="recipe-rowprovider-fn" spellcheck="false">
function element2RowArray(element) {${recipe.rpfn || defaultRowProviderBody}}
</pre>
      </div>

      <input type="hidden" value="${recipe.id || ''}" class="recipe-id" />
      <input type="hidden" value="${recipe.status || 'active'}" class="recipe-status" />
      <div class="errors"></div>
      <div class="form-actions">
        <input type="submit" class="btn btn-primary btn-save" value="Save" />
        <input type="button" class="btn btn-default btn-test" value="Test" />
        <input type="button" class="btn btn-default btn-collapse" value="Collapse" />
        <span class="divider"></span>
        <input type="button" class="btn btn-danger btn-delete" value="Delete" />
      </div>
    `;

    this.wrapper_.appendChild(form);
    form.addEventListener('submit', this.handleNewRecipeSubmit_.bind(this, form));
    form.querySelector('.btn-delete')
        .addEventListener('click', this.handleRecipeDelete_.bind(this, form, recipe));
    form.querySelector('.btn-test')
        .addEventListener('click', this.handleRecipeTest_.bind(this, form));
    form.querySelector('.btn-export')
        .addEventListener('click', this.handleRecipeDownload_.bind(this, form));
    form.querySelector('.btn-toggle-status')
        .addEventListener('click', this.handleRecipeToggle_.bind(this, form, recipe));
        
    form.querySelector('.btn-edit')
        .addEventListener('click', () => {
          form.className = '';
        });
    form.querySelector('.btn-collapse')
        .addEventListener('click', () => {
          form.className = 'collapsed';
        });

    if (expand) {
      form.className = '';
      form.querySelector('input').focus();
    }
  }

  getFormValues_(form) {
    let fn = form.querySelector('.recipe-fn').innerText.trim();
    if (fn.includes('function element2DataTable(element) {') && fn.endsWith('}')) {
      fn = fn.replace('function element2DataTable(element) {', '');
      fn = fn.slice(0, fn.length - 1);
    }

    let rpfn = form.querySelector('.recipe-rowprovider-fn').innerText.trim();
    if (rpfn.includes('function element2RowArray(element) {') && rpfn.endsWith('}')) {
      rpfn = rpfn.replace('function element2RowArray(element) {', '');
      rpfn = rpfn.slice(0, rpfn.length - 1);
    }

    const getVal = (form, sel) => form.querySelector(`form ${sel}`).value.trim();
    const recipe = {
      id: getVal(form, '.recipe-id'),
      status: getVal(form, '.recipe-status'),
      selector: getVal(form, '.recipe-selector'),
      fn,
      rpfn,
      name: getVal(form, '.recipe-name'),
      description: getVal(form, '.recipe-desc'),
      urlRegex: getVal(form, '.recipe-url-regex'),
      urlExample: getVal(form, '.recipe-url-example'),
      updated: Date.now(),
      disabled: false,
    };
    return recipe;
  }

  handleNewRecipeSubmit_(form, e) {
    e.preventDefault();
    
    const recipe = this.getFormValues_(form);
    this.saveRecipe_(form, recipe)
        .then(() => this.clearFormError_(form))
        .catch(err => this.handleFormError_(form, err));

    return false;
  }

  handleRecipeToggle_(form, recipe) {
    recipe.disabled = !recipe.disabled;
    this.saveRecipe_(form, recipe)
        .then(() => {
          form.classList.toggle("form-disabled", recipe.disabled);
          const toggleBtn = form.querySelector(".btn.btn-toggle-status");
          toggleBtn.value = recipe.disabled ? "Enable" : "Disable";

          this.clearFormError_(form);
        })
        .catch(err => this.handleFormError_(form, err));
  }

  handleRecipeDownload_(form) {
    const recipe = this.getFormValues_(form);
    const simpleName = recipe.name.replace(/[\s-_!,%.':\[\]\{\}?]+/g, '-');

    const blob = new Blob([JSON.stringify(recipe, null, 2)], {type: "application/json;charset=utf-8"});
    saveAs(blob, `recipe.${simpleName}.json`);
  }

  handleRecipeTest_(form) {
    const {urlRegex, urlExample, fn} = this.getFormValues_(form);

    try {
      eval(`function element2DataTable(element) {${fn}}`);
    } catch (err) {
      return this.handleFormError_(form, new Error(`There's a javascript error in your function.`));
    }

    if (!urlRegex || !urlExample) {
      return this.handleFormError_(form, new Error('Please provide a valid example url and regex'));
    }
    const matches = urlExample.match(urlRegex);
    if (matches && matches.length) {
      this.handleFormSuccess_(form);
    } else {
      this.handleFormError_(form, new Error('The provided regex did not match.'));
    }
  }

  handleRecipeDelete_(form, recipe) {
    form.remove();

    if (recipe.id && this.recipesById_[recipe.id]) {
      this.recipesById_[recipe.id].status = 'archived';
      this.saveRecipes_(Object.values(this.recipesById_));
    } else {
      // No-op.
    }

    if (this.isWithoutActiveRecipes()) {
      this.renderNoRecipes_();
    }
  }

  saveRecipe_(form, recipe) {
    this.recipesById_[recipe.id] = recipe;
    return this
        .saveRecipes_(Object.values(this.recipesById_))
        .then(() => {
          this.handleFormSuccess_(form, recipe);
          return Promise.resolve();
        });
  }

  saveRecipes_(recipes) {
    return this.browserEnv_.setWorld('_recipe_world', {recipes});
  }

  handleFormSuccess_(form, recipe=null) {
    if (recipe) {
      form.querySelector('.collapsed-header span').innerText = recipe.name || 'None';
    }

    form.classList.add('success');
    window.setTimeout(() => {
      form.classList.remove('success');
    }, 1000);
  }

  clearFormError_(form) {
    form.querySelector('.errors').innerHTML = '';
  }

  handleFormError_(form, err) {
    const message = (err && err.message) ? err.message : 'Unknown error';
    const wrapper = form.querySelector('.errors');
    wrapper.innerHTML = '';
    wrapper.appendChild(createAlertPane(message, 'danger'));
  }

  handleError_(err) {
    const message = (err && err.message)
        ? `Error caught: ${err.message}`
        : 'Error caught!';
    const wrapper = document.querySelector('.global-errors');
    wrapper.appendChild(createAlertPane(message, 'danger', true));
  }
}
