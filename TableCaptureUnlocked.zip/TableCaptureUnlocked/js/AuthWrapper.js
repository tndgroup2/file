
class AuthWrapper {
  constructor() {
    this.googleToken_ = null;
  }

  getGoogleToken() {
    return new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({interactive: true}, (token) => {
        if (token) {
          this.googleToken_ = token;
          resolve(token);
        } else {
          reject(new Error("Unable to retrieve auth token."));
        }
      });
    });
  }
}
