
class RecipeTableWrapper extends SpecialCaseElementWrapper {
  constructor(recipe, element, url, pageTitle, windowName, userConfig) {
    super(element, url, pageTitle, windowName, userConfig);

    this.recipe_ = recipe;
    this.define_();
  }

  getTableId() {
    return this.recipe_.name;
  }

  isRecordable() {
    return this.recipe_
        && this.recipe_.rpfn
        && !this.recipe_.rpfn.trim().endsWith("return [];");
  }

  isTableRecipe_() {
    const el = this.getDomElement();
    return el && ["TABLE", "TBODY", "THEAD"].includes(el.tagName)
  }

  snoop() {
    const defaultTableRootValueProvider = (el) => TableUtil.nodeToArrays(
      el, _TCAP_COPY_CONST.rowSeparator, _TCAP_COPY_CONST.colSeparator, this.userConfig_, window.location.origin, true);
    const defaultTableRowValueProvider = (el) => TableUtil.trNodeToRowArray(
      el, _TCAP_COPY_CONST.colSeparator, this.userConfig_, window.location.origin);
    const defaultArbRootValueProvider = (el) => TableUtil.getArbPreAlignmentForRoot(
      el, this.userConfig_, window.location.origin);
    const defaultArbRowValueProvider = (el) => TableUtil.getArbPreAlignmentForNode(
      el, this.userConfig_, window.location.origin);
    
    let usingDefaults = true;
    let rootValueProvider = null;
    let rowValueProvider = null;
    try {
      const fn = eval(`(element, userConfig, basePath) => { ${this.recipe_.fn} }`);
      const rpfn = eval(`(element, userConfig, basePath) => { ${this.recipe_.rpfn} }`);
      rowValueProvider = (element) => rpfn(element, this.userConfig_, window.location.origin);
      rootValueProvider = (element) => fn(element, this.userConfig_, window.location.origin);
      usingDefaults = false;
    } catch (err) {
      throw err;
    }

    if (this.isTableRecipe_()) {
      rootValueProvider = rootValueProvider || defaultTableRootValueProvider;
      rowValueProvider = rowValueProvider || defaultTableRowValueProvider;
      this.snoop_ = new TableMutationSnoop(this.getDomElement(), rootValueProvider, rowValueProvider);
    } else {
      rootValueProvider = rootValueProvider || defaultArbRootValueProvider;
      rowValueProvider = rowValueProvider || defaultArbRowValueProvider;
      this.snoop_ = new ArbMutationSnoop(this.getDomElement(), rootValueProvider, rowValueProvider);
      if (usingDefaults) {
        this.snoop_.setValuesPostProcessor(valueArray => TableUtil.arbAlign(valueArray, false));
      }
    }

    return this.snoop_;
  }

  isValid() {
    return true;
  }

  define_ () {
    const element = this.dom.element;
    const {id, pathTo} = this.getDomAttributes_(element);
    const alignedArray = this.getAsArrays();

    const rows = alignedArray
    const nRows = rows.length;
    const nCols = (rows && rows.length)
        ? rows[0].length
        : 0;

    // Note: Trailing space is intended.
    const size = `(${nRows} x ${nCols}) `;

    this.def = {
      recipe: this.recipe_,
      pathTo,
      numCells: nRows * nCols,
      table : {
        id: size + id,
        adjusted: `${size} ${this.recipe_.name} (Recipe)`,
        rows: nRows,
        columns: nCols,
        windowName: this.windowName,
      },
    };
  }

  getAsArrays() {
    try {
      const fn = eval(`(element, userConfig, basePath) => { ${this.recipe_.fn} }`);
      const arrays = fn(this.dom.element, this.userConfig_, window.location.origin);

      const re_n  = new RegExp('\\n', 'g');
      const re_t  = new RegExp('\\t', 'g');
      return arrays.map(arr => {
        return arr.map(val => {
          if (val) {
            val = val.replace(re_n, '');
            val = val.replace(re_t, '');
            return val.trim();
          }
          return val;
        });
      });
    } catch (err) {
      // NOTE(gmike): This happens when the recipe is fucked. Nothing to do.
      console.log('RecipeTableWrapper::getAsArrays', err);
    }

    return [];
  }

  getData() {
    return {
      dataArray: this.getAsArrays(),
      rows: this.def.table.rows,
      cols: this.def.table.columns,
    };
  }
}
