
class WorkshopFrame {
  constructor() {
    this.el_ = null;
    this.callbacks_ = {};

    window.addEventListener('resize', this.sizeQueen_.bind(this));
  }

  bindToEvent(event, cb) {
    if (!this.callbacks_[event]) {
      this.callbacks_[event] = [];
    }
    this.callbacks_[event].push(cb);
  }

  render() {
    const icon = chrome.extension.getURL('/') + 'images/icon.png';

    let el = document.createElement('tc-workshop');
    if (document.querySelector('tc-workshop')) {
      el = document.querySelector('tc-workshop');
      el.classList.remove('dead');
    }

    el.innerHTML = `
      <div class="inner">

        <!-- SIZE QUEEN -->
        <div class="size-queen too-small-window-message">This window is too small. Try making it bigger to use Table Capture.</div>
        <div class="size-queen too-small-frame-message">This frame is too small. <a>Click here</a> to maximize it to continue using Table Capture.</div>

        <div class="_tc-header">
          <div class="_tc-brand">
            <div class="_tc-logo-wrapper">
              <img src="${icon}" />
            </div>
            <div class="frame-title">
              <span class="frame-title-context"></span>
              <div class="lds-heart tc-hidden">
                <div></div>
              </div>
            </div>
          </div>
          <div class="_tc-actions">
            <div class="pro-cta not-tc-pro tc-hidden">
              <span>Upgrade to <span class="_tc-strong">Pro</span></span>
            </div>
          </div>
        </div>
        <div class="_tc-content"></div>
      </div>
    `;

    const actionWrapper = el.querySelector('._tc-actions');
    this.getActions_().forEach(def => {
      const action = document.createElement('div');
      action.className = `_tc-action _tc-action-${def.key}`;
      action.innerHTML = `<span>${def.char}</span>`;
      action.addEventListener('click', def.handler);
      action.addEventListener('mouseenter', this.fireFrameActionMouseOver_.bind(this, def.tooltip));
      action.addEventListener('mouseleave', this.fireFrameActionMouseExit_.bind(this));

      actionWrapper.appendChild(action);
    });

    document.body.appendChild(el);
    this.el_ = el;

    this.el_
        .querySelector('._tc-logo-wrapper')
        .addEventListener('click', this.fireEvent_.bind(this, WorkshopEvent.SEARCH));

    this.el_
        .querySelector('.pro-cta')
        .addEventListener('click', () => {
          window.open(chrome.extension.getURL("/upgrade.html?ref=bwokeshop"));
        });
    Array
        .from(this.el_.querySelectorAll('.size-queen a'))
        .forEach(a => a.addEventListener('click', this.triggerFrameExpansion_.bind(this)));

    const dockPos = this.getDockPosition_();
    if (dockPos === "top") {
      this.dockTop();
    } else {
      this.dockBottom();
    }

    const maxMin = this.getDockMaxMin_();
    if (maxMin === "min") {
      this.minimize();
    } else {
      this.maximize();
    }

    this.sizeQueen_();
    this.iframeCheck_();

    return el.querySelector('._tc-content');
  }

  renderSuccess(message) {
    this.setTooltip(message);
    this.el_.classList.add('success');
    window.setTimeout(() => {
      this.el_.classList.remove('success');
      this.setTooltip('');
    }, 2 * 1000);
  }

  renderStatus(message) {
    this.setTooltip(message);
    this.el_.classList.add('statusy');
    window.setTimeout(() => {
      this.el_.classList.remove('statusy');
      this.setTooltip('');
    }, 5 * 1000);
  }

  renderError(message) {
    this.setTooltip(message);
    this.el_.classList.add('erroring');
    window.setTimeout(() => {
      this.el_.classList.remove('erroring');
      this.setTooltip('');
    }, 5 * 1000);
  }

  renderIFrameHint_() {
    const src = window.location.href;
    const message = `Table Capture is operating within an iFrame. You may need to scroll to the bottom to see the workshop.`;
    const hint = document.createElement('tc-iframe-hint');
    hint.innerHTML = `<div>
      <span>
        ${message}
        You can also try <a target="_blank" href="${src}">opening the frame</a> in its own tab and trying again.
      </span>
    </div>`;
    hint.addEventListener('click', () => {
      hint.remove();
    });
    document.body.appendChild(hint);
  }

  upgradeJingle() {
    const cta = this.el_.querySelector('.pro-cta');
    cta.classList.add('jingle');
    window.setTimeout(() => {
      cta.classList.remove('jingle');
    }, 2 * 1000);
  }

  setTooltip(text) {
    this.el_.querySelector('.frame-title-context').innerHTML = text;
  }

  setLoading(loading) {
    this.el_.querySelector('.lds-heart').classList.toggle('tc-hidden', !loading);
    this.el_.classList.toggle('tc-loading', loading);
  }

  dockTop() {
    this.el_.classList.remove('dock-bottom');
    this.el_.classList.remove('dock-full');
    this.el_.classList.add('dock-top');

    this.setDockPosition_("top");
  }

  dockBottom() {
    this.el_.classList.add('dock-bottom');
    this.el_.classList.remove('dock-full');
    this.el_.classList.remove('dock-top');

    this.setDockPosition_("bottom");
  }

  goFull() {
    this.el_.classList.remove('dock-bottom');
    this.el_.classList.remove('dock-top');
    this.el_.classList.add('dock-full');
  }

  isMinimized() {
    return this.el_ && this.el_.classList.contains('minimized');
  }

  minimize() {
    this.el_.classList.add('minimized');
    this.el_.classList.remove('maximized');

    this.setDockMaxMin_("min");
  }

  maximize() {
    this.el_.classList.remove('minimized');
    this.el_.classList.add('maximized');

    this.setDockMaxMin_("max");
  }

  remove() {
    this.el_.classList.add('dead');
    this.setDockMaxMin_("max");
  }

  //// LAZY STATE MEM

  getDockMaxMin_() {
    const key = this.getDockMaxMinKey_();
    return window.localStorage[key] || "max";
  }

  setDockMaxMin_(maxMin) {
    const key = this.getDockMaxMinKey_();
    window.localStorage[key] = maxMin;
  }

  getDockMaxMinKey_() {
    let key = window.location.hostname.replace(/\./g, "_");
    return '_tc-workshop-dock-maxmin-' + key;
  }

  getDockPosition_() {
    const key = this.getDockPositionKey_();
    return window.localStorage[key] || "bottom";
  }

  setDockPosition_(pos) {
    const key = this.getDockPositionKey_();
    window.localStorage[key] = pos;
  }

  getDockPositionKey_() {
    let key = window.location.hostname.replace(/\./g, "_");
    return '_tc-workshop-dock-pos-' + key;
  }

  ////

  fireEvent_(event) {
    _tcLogEvent(`WorkshopEvent.${event}`);

    if (this.callbacks_[event]) {
      this.callbacks_[event].forEach(cb => cb());
    }
  }

  fireFrameActionMouseOver_(tooltip) {
    (this.callbacks_[WorkshopEvent.TOOLTIP_SHOW] || [])
        .forEach(cb => cb(tooltip));
  }

  fireFrameActionMouseExit_() {
    (this.callbacks_[WorkshopEvent.TOOLTIP_CLEAR] || [])
        .forEach(cb => cb());
  }

  handleTopDock_() {
    this.dockTop();
  }

  handleBottomDock_() {
    this.dockBottom();
  }

  handleFullScreen_() {
    this.fireEvent_(WorkshopEvent.FULLSCREEN_ENTER);
    this.goFull();
  }

  handleFullScreenExit_() {
    this.fireEvent_(WorkshopEvent.FULLSCREEN_EXIT);
    this.dockBottom();
  }

  handleGlimpse_() {
    this.fireEvent_(WorkshopEvent.GLIMPSE);

    this.el_.classList.add('glimpse');
    window.setTimeout(() => {
      this.el_.classList.remove('glimpse');
    }, 3 * 1000);
  }

  handleMaximize_() {
    this.fireEvent_(WorkshopEvent.MAXIMIZE);
    this.maximize();
  }

  handleMinimize_() {
    this.fireEvent_(WorkshopEvent.MINIMIZE);
    this.minimize();
  }

  handleClear_() {
    this.fireEvent_(WorkshopEvent.CLEAR);
  }

  handleRemove_() {
    this.fireEvent_(WorkshopEvent.REMOVE);
    this.remove();
  }

  handleSupport_() {
    let url = _TCAP_CONFIG.reportPageUrl;
    url = url.replace('$URL', btoa(window.location.href));
    window.open(url);
  }

  triggerFrameExpansion_() {
    this.fireEvent_(WorkshopEvent.FRAME_EXPAND);
  }

  isTooFuckingSmall_() {
    return window.innerHeight < 500 || window.innerWidth < 768;
  }

  iframeCheck_() {
    if (window !== top) {
      window.setTimeout(() => {
        let bound = this.el_.getBoundingClientRect();
        let winHeight = window.outerHeight;
        if (bound.bottom > (winHeight * 2)) {
          this.renderIFrameHint_();
        }
      }, 500);
    }
  }

  sizeQueen_() {
    const topWindow = window == top;
    const tooSmall = this.isTooFuckingSmall_();

    this.el_.classList.toggle('too-small-window', topWindow && tooSmall);
    this.el_.classList.toggle('too-small-frame', !topWindow && tooSmall);
  }

  getActions_() {
    const actions = [
      {
        title: 'Support',
        key: 'bugreport',
        handler: this.handleSupport_.bind(this),
        char: '?',
        tooltip: chrome.i18n.getMessage('workshopFrameSupportTooltip'),
      },
      {
        title: 'Clear',
        key: 'clear',
        handler: this.handleClear_.bind(this),
        char: '⌫',
        tooltip: chrome.i18n.getMessage('workshopFrameClearTooltip'),
      },
      {
        title: 'Dock Top',
        key: 'topdock',
        handler: this.handleTopDock_.bind(this),
        char: '↑',
        tooltip: chrome.i18n.getMessage('workshopFrameTopDockTooltip'),
      },
      {
        title: 'Dock Bottom',
        key: 'bottomdock',
        handler: this.handleBottomDock_.bind(this),
        char: '↓',
        tooltip: chrome.i18n.getMessage('workshopFrameBottomDockTooltip'),
      },
      {
        title: 'Glimpse',
        key: 'glimpse',
        handler: this.handleGlimpse_.bind(this),
        char: '◯',
        tooltip: chrome.i18n.getMessage('workshopFrameGlimpseTooltip'),
      },
      {
        title: 'Minimize',
        key: 'minimize',
        handler: this.handleMinimize_.bind(this),
        char: '_',
        tooltip: chrome.i18n.getMessage('workshopFrameMinimizeTooltip'),
      },
      {
        title: 'Maximize',
        key: 'maximize',
        handler: this.handleMaximize_.bind(this),
        char: '☐',
        tooltip: chrome.i18n.getMessage('workshopFrameMaximizeTooltip'),
      },
      {
        title: 'Full Screen',
        key: 'fullscreen',
        handler: this.handleFullScreen_.bind(this),
        char: '⇱',
        tooltip: chrome.i18n.getMessage('workshopFrameFullScreenTooltip'),
      },
      {
        title: 'Exit Full Screen',
        key: 'exitfullscreen',
        handler: this.handleFullScreenExit_.bind(this),
        char: '⇲',
        tooltip: chrome.i18n.getMessage('workshopFrameFullScreenExitTooltip'),
      },
      {
        title: 'Remove',
        key: 'remove',
        handler: this.handleRemove_.bind(this),
        char: '×',
        tooltip: chrome.i18n.getMessage('workshopFrameRemoveTooltip'),
      },
    ];
    return actions
  }
}
