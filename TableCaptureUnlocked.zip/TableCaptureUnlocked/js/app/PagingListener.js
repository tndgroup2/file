
class PagingListener {
  constructor() {
    this.paging_ = false;
    this.listening_ = false;
    this.elementWrapper_ = null;
    this.tabId_ = null;
    this.count_ = 0;
    this.data_ = null;
    this.popableData_ = null;
    this.treatAsTable_ = true;
    this.autoPageTable_ = false;

    this.clickedElementsTimeout_ = null;
    this.clickedElements_ = [];
    this.contextMenuElement_ = null;
    this.pagingElement_ = null;
  }

  destroy() {
    this.elementWrapper_ = null;
    this.pagingElement_ = null;
    this.setCount(0);
    this.stopPaging();
    this.maybeKillAutoPage_();
  }

  maybeKillAutoPage_() {
    this.autoPageTable_ = false;

    if (this.pageAdvanceTimeout_) {
      window.clearTimeout(this.pageAdvanceTimeout_);
      this.pageAdvanceTimeout_ = null;
    }

    this.updateAutoPageState_();
  }

  updateAutoPageState_() {
    const params = {
      action: MessageAction.AUTO_PAGING_UPDATE,
      autoPageTable: this.autoPageTable_,
    };
    new BrowserEnv()
        .sendMessage(params)
        .catch(err => _tcContentSwallowError(err, 'PagingListener::updateAutoPageState_()'));
  }

  isAutoPaging() {
    return this.autoPageTable_;
  }

  setContextMenuElement(contextMenuElement) {
    this.contextMenuElement_ = contextMenuElement;
  }

  setAutoPage(autoPageTable) {
    this.autoPageTable_ = autoPageTable;

    if (this.autoPageTable_) {
      this.updateAutoPageState_();
    } else {
      this.maybeKillAutoPage_();
    }
  }

  setTreatAsTable(treatAsTable) {
    this.treatAsTable_ = treatAsTable;
  }

  setPaging(paging) {
    this.paging_ = paging;
  }

  isPaging() {
    return this.paging_;
  }

  getData() {
    return this.data_;
  }

  getDataArrayAsString_(outputFormat) {
    const str = TableUtil.arrayOfArraysToString(this.data_.dataArray, _TCAP_COPY_CONST.rowSeparator, _TCAP_COPY_CONST.colSeparator);
    return TableUtil.postProcessFinalString(str, outputFormat, _TCAP_COPY_CONST);
  }

  setData(data, popable=false) {
    this.data_ = JSON.parse(JSON.stringify(data));
    this.data_.dataArray = JSON.parse(JSON.stringify(this.data_.dataArray));

    if (popable) {
      this.popableData_ = JSON.parse(JSON.stringify(data));;
    }

    if (this.isPaging()) {
      const params = {
        action: MessageAction.PAGING_DATA_UPDATE,
        count: this.count_,
        // NOTE(gmike): This has been stringified and parsed. Can be sent over the wire.
        data: this.data_,
      };
      new BrowserEnv()
          .sendMessage(params)
          .catch(err => _tcContentSwallowError(err, 'PagingListener::setData()'));
    }
  }

  popData() {
    if (this.popableData_) {
      this.data_ = JSON.parse(JSON.stringify(this.popableData_));
    }
  }

  setCount(count) {
    this.count_ = count;
  }

  getCount() {
    return this.count_;
  }

  beginPagingListening(tabId, elementWrapper) {
    this.tabId_ = tabId;
    this.elementWrapper_ = elementWrapper;
    this.listening_ = true;

    Array
        .from(document.querySelectorAll('*'))
        .forEach(el => this.waitForClick_(el));
  }

  stopPaging() {
    this.listening_ = false;
    this.paging_ = false;
    this.count_ = 0;

    const params = {
      tabId: this.tabId_,
      action: MessageAction.PAGING_LISTEN_STOP,
      host: window.location.host,
    };
    new BrowserEnv()
        .sendMessage(params)
        .catch(err => _tcContentSwallowError(err, 'PagingListener::stopPaging()'));
  }

  copy(outputFormat) {
    const params = {
      action : MessageAction.COPY_STRING,
      stringData : this.getDataArrayAsString_(outputFormat),
    };
    return new BrowserEnv().sendMessage(params);
  }

  waitForClick_(el) {
    // TODO(gmike): We may want to save these for removal later.
    const fn = this.handleClick_.bind(this, el);
    el.addEventListener('mousedown', fn);
  }

  handleClick_(el, e) {
    if (this.listening_ && this.elementWrapper_) {
      if (isNodeWorkshopChild(el) || el.nodeName === 'HTML' || el.nodeName === 'BODY') {
        // No-op.
      } else {
        if (this.clickedElementsTimeout_) {
          window.clearTimeout(this.clickedElementsTimeout_);
        }
        this.clickedElements_.push(el);
        this.clickedElementsTimeout_ = window.setTimeout(this.handleClickedElements_.bind(this), 50);
      }
    }
    return true;
  }

  handleClickedElements_() {
    if (this.clickedElements_ && this.clickedElements_.length) {
      if (this.contextMenuElement_ && this.clickedElements_.includes(this.contextMenuElement_)) {
        this.recordPagingElement_(this.contextMenuElement_);
      } else {
        const el = this.clickedElements_.shift();
        this.recordPagingElement_(el);
      }
    }
  }

  recordPagingElement_(el) {
    if (!this.data_) {
      throw new Error('Unable to begin paging');
    }

    this.pagingElement_ = el;
    const pathToPager = _tcGetPathTo(this.pagingElement_);
    const {pathTo} = this.elementWrapper_.toJSON();
    const {rows, cols, dataArray} = this.data_;

    const params = {
      tabId: this.tabId_,
      action: MessageAction.PAGING_LISTEN_START,
      pathToPager,
      treatAsTable: this.treatAsTable_,
      autoPageTable: this.autoPageTable_,
      pathToElement: pathTo,
      count: this.count_,
      host: window.location.host,
      data: {rows, cols, dataArray},
    };
    new BrowserEnv()
        .sendMessage(params)
        .catch(err => _tcContentSwallowError(err, 'PagingListener::recordPagingElement_()'));
  }

  tryNextPageNav(pathToPager) {
    if (!this.isAutoPaging()) {
      // No-op.
      return Promise.resolve();
    }

    this.pageAdvanceTimeout_ = window.setTimeout(() => {
      const currentPageNum = _tcGetCurrentPageNumber();

      let pagingEl = null;
      if (currentPageNum !== null) {
        pagingEl = _tcGetNextPageElement(currentPageNum);
      }
      if (pagingEl === null) {
        pagingEl = _tcGetElementByXpath(pathToPager)
      }

      if (pagingEl) {
        _tcDoClick(pagingEl);
      } else {
        // No-op.
      }
    }, _TCAP_CONFIG.autoPageWait);
  }
}
