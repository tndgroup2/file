
function _tcLogEvent(event, context) {
  try {
    const params = {
      action: MessageAction.LOG_EVENT,
      pageUrl: window.location.href,
      event,
      context,
    };

    chrome.runtime.sendMessage(params, () => {});
  } catch (err) {
    // No-op.
  }
}

function _tcExecEmbeddedCode(snippet) {
  const script = document.createElement('script');
  script.textContent = snippet;
  (document.head||document.documentElement).appendChild(script);
  script.remove();
}

function _tcOpenGoogleSheets(enablePastePrompt) {
  const params = {
    url: _TCAP_CONFIG.newSheetsUrl,
    outputFormat: OutputFormat.GOOG,
    enablePastePrompt,
  };
  return new BrowserEnv().sendMessage(params);
}

function checkIsPagePdf() {
  try {
    if (document.body.childNodes.length != 0) {
      const node = document.body.childNodes[0];
      const {type, tagName, src} = node;
      return (type === 'application/pdf' && tagName === 'EMBED');
      /*
        // NOTE(gmike): This wasn't working as of v9.9.26. src was 'about:blank'
        return type === 'application/pdf'
            && tagName === 'EMBED'
            && src
            && src.includes(".pdf");
      */
    }
  } catch (err) {}
  return false;
}

function _tcGetWindowName(win) {
  return win['tcap-id'];
}

function _tcRandString() {
  return Math.random().toString(36).slice(2);
}

function getSetWindowId(win) {
  const id = _tcRandString().substring(0, 4);
  win['tcap-id'] = id;
  return id;
}

function _tcContentSwallowError(err, context) {
  try {
    _TCAP_CONFIG.devDebug &&
        console.log(`${context} Error Caught: `, err);
  } catch (e) {
    // No-op.
  }
}
