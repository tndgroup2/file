
class SheetsSyncBridge {
  constructor(tabId) {
    this.tabId_ = tabId;
    this.sheetWriteInterval_ = null;
    this.writeParams_ = null;
  }

  createSheet(instanceId) {
    const params = {
      tabId: this.tabId_,
      title: `Table Capture Cloud + ${window.location.hostname}`,
      action: MessageAction.SHEET_SYNC_CREATE,
      host: window.location.host,
      instanceId,
    };
    return new BrowserEnv()
        .sendMessage(params)
        .then(response => {
          if (!this.sheetWriteInterval_) {
            this.sheetWriteInterval_ = window.setInterval(this.performDataWrite_.bind(this), _TCAP_CONFIG.sheetSyncWriteInterval);
          }
          return response;
        });
  }

  performDataWrite_() {
    return new BrowserEnv()
        .sendMessage(this.writeParams_)
        .then(this.resolve_)
        .catch(this.reject_);
  }

  writeToSheet(instanceId, sheet, dataArray, writeNow=false) {
    this.writeParams_ = {
      tabId: this.tabId_,
      action: MessageAction.SHEET_SYNC_WRITE,
      sheetId: sheet.id,
      instanceId,
      dataArray,
    };

    return new Promise((resolve, reject) => {
      this.resolve_ = resolve;
      this.reject_ = reject;

      if (writeNow) {
        this.performDataWrite_();
      }
    });
  }
}
