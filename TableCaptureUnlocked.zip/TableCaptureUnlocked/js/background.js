const tables = {};
const tabToFrames = {};
const tabToUrls = {};
const tabToPdfState = {};
const tabToPagingState = {};
let activityContextMenuMap = {};
const contextMenuMap = {};
const recipeContextMenuMap = {};
const browserEnv = new BrowserEnv();

let activeTableDefs = null;
let selectedId = null;
let activeEditableTable = null;
let activeCloudRepro = null;

// SHEET SYNC
const sheetsSync = new SheetsSync();
const authWrapper = new AuthWrapper();
const gsheetMap = {};

//// USER CONFIG

const LICENSE_CHECK_NUM = 14;
let USER_CONFIG = null;
let USER_CONFIG_CACHE_HIT_COUNT = 0;

browserEnv.addStorageChangeListener(updateLocalUserConfig);
updateLocalUserConfig();

function updateLocalUserConfig() {
  return getExtensionUserConfig()
    .then((userConfig) => {
      USER_CONFIG = userConfig;
      USER_CONFIG_CACHE_HIT_COUNT = 0;
      return USER_CONFIG;
    })
    .catch(err => swallowError(err, 'updateLocalUserConfig-getExtensionUserConfig'));
}

function syncGetCachedExtensionUserConfig() {
  return USER_CONFIG;
}

function getCachedExtensionUserConfig() {
  if (USER_CONFIG) {
    USER_CONFIG_CACHE_HIT_COUNT++;
    if (USER_CONFIG.paidPro && USER_CONFIG_CACHE_HIT_COUNT > LICENSE_CHECK_NUM) {
      USER_CONFIG_CACHE_HIT_COUNT = 0;
      backgroundCheckSetLicense(USER_CONFIG);
    }
    return Promise.resolve(USER_CONFIG);
  }
  return updateLocalUserConfig();
}

function backgroundCheckSetLicense(userConfig) {
  const {licenseCode} = userConfig;

  const url = `${_TCAP_CONFIG.licenseUrl}/${licenseCode}?activate=0&licensecheck=1`;
  fetch(url)
    .then(response => {
      if (response.ok) {
        return response.json();
      }
      return response
          .json()
          .then(errResponse => {
            throw errResponse;
          });
    })
    .then(response => {
      let activeCloudLicenses = [];
      let activeProLicenses = [];
      if (response && response.licenses) {
        const now = new Date().getTime();
        const activeLicenses = response.licenses
            .filter(l => !l.cancelled)
            .filter(l => Number(l.expiration) > now);
        activeProLicenses = activeLicenses
            .filter(l => {
              return l.product === _TCAP_CONFIG.licenseProduct || _TCAP_CONFIG.adjacentProducts.includes(l.product);
            });
        activeCloudLicenses = activeLicenses
            .filter(l => {
              return _TCAP_CONFIG.cloudLicenseProducts.includes(l.product);
            });
      }

      return browserEnv
          .getSyncStorageApi()
          .setP({
            paidPro: activeProLicenses.length > 0,
            paidCloud: activeCloudLicenses.length > 0,
          });
    })
    .catch(err => swallowError(err, 'backgroundCheckSetLicense'));
}

////

function swallowError(err, context="", noPrint=false) {
  if (noPrint) {
    // Legit swallow.
  } else {
    console.error(`background.js::swallowError(${context})`, err);
  }
}

function createTabFrameEntryIfDNE(tabId, frameId, obj) {
  if (!obj[tabId]) {
    obj[tabId] = {};
  }
  if (!obj[tabId][frameId]) {
    obj[tabId][frameId] = {};
  }
}

function getActiveTableDefs() {
  return activeTableDefs;
}

function queryTab(tabId) {
  return new Promise((resolve) => {
    chrome.tabs.get(tabId, resolve);
  });
}

function queryActiveTab(context = "") {
  return new Promise((resolve, reject) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (browserEnv.hasRuntimeError()) {
        reject(browserEnv.getRuntimeError());
      } else if (!tabs || tabs.length != 1) {
        reject(new Error(`Tab not found: ${context}`));
      } else {
        resolve(tabs[0]);
      }
    });
  });
}

function overrideActiveTab() {
  return queryActiveTab("overrideActiveTab").then((tab) => {
    selectedId = tab.id;
    return Promise.resolve(selectedId);
  });
}

function getSelectedTabId() {
  if (selectedId) {
    return Promise.resolve(selectedId);
  }
  return overrideActiveTab();
}

function performTabScreenshot(tabId) {
  return new Promise((resolve, reject) => {
    try {
      const opts = { format: "png" };
      chrome.tabs.captureVisibleTab(null, opts, resolve);
    } catch (err) {
      reject(err);
    }
  });
}

function killFrame(tabId, frameId) {
  try {
    if (tables[tabId]) {
      delete tables[tabId][frameId];
    } else {
      console.log(
        `background.killFrame (tabId = ${tabId}, frameId = ${frameId}): Weird: tables[tabId] does not exist.`
      );
    }
  } catch (err) {
    console.log(
      `background.killFrame (tabId = ${tabId}, frameId = ${frameId}): Err`,
      err
    );
  }
}

function hasTables(tableDefinitionsArray) {
  return getNumTables(tableDefinitionsArray) > 0;
}

function getNumTables(tableDefinitions) {
  if (!tableDefinitions) {
    return 0;
  }

  const keys = Object.keys(tableDefinitions);
  if (!keys || !keys.length) {
    return 0;
  }
  let count = 0;
  keys.forEach((key) => {
    const def = tableDefinitions[key];
    if (def && def.tables) {
      count += def.tables.length;
    }
  });
  return count;
}

function updatePdfState(tabId, isPdf) {
  tabToPdfState[tabId] = isPdf;

  if (isPdf && tabId === selectedId) {
    updateContextMenusForPdf();
  }
}

function isActiveTabPdfPage() {
  return selectedId && !!tabToPdfState[selectedId];
}

function updatePageUrl(tabId, frameId, pageUrl) {
  // If it's not frame 0, it's not the TOP.
  if (frameId === 0) {
    tabToUrls[tabId] = pageUrl;
  }
}

function getPageUrlForTab(tabId) {
  return tabToUrls[tabId];
}

function getPageUrlForActiveTab() {
  if (selectedId) {
    return tabToUrls[selectedId];
  }
  return null;
}

function updateSelected(tabId) {
  selectedId = tabId;
  activeTableDefs = tables[tabId];

  if (isActiveTabPdfPage()) {
    updateContextMenusForPdf();
  } else {
    checkMatchingRecipesAndStarred(tabId);
    updateContextMenus();
  }

  const tableDefs = tables[tabId];
  if (hasTables(tableDefs)) {
    chrome.pageAction.setTitle({
      tabId,
      title: chrome.i18n.getMessage("pageActionTitle", [
        getNumTables(tableDefs),
      ]),
    });
  }
}

function updateTableResponseFrameId(tableResponse, frameId) {
  if (!tableResponse) {
    return;
  }

  if (tableResponse.tables && tableResponse.tables.length > 0) {
    tableResponse.tables.forEach((def) => (def.frameId = frameId));
  }

  if (tableResponse.selectedElement) {
    tableResponse.selectedElement.frameId = frameId;
  }
}

function updateWithTables(tabId, frameId, tableResponse) {
  if (tabId < 0) {
    return;
  }

  if (!tables[tabId]) {
    tables[tabId] = {};
  }

  if (tableResponse) {
    updateTableResponseFrameId(tableResponse, frameId);
    tables[tabId][frameId] = tableResponse;
  }

  const isPdf = tableResponse && tableResponse.isPdf;
  const pageUrl = tableResponse && tableResponse.pageUrl;
  const path = hasTables(tables[tabId])
    ? "images/icon.addressbar.19.gif"
    : "images/icon.addressbar.19.grey.gif";

  chrome.pageAction.show(tabId);
  chrome.pageAction.setIcon({
    tabId,
    path,
  });

  if (selectedId == tabId) {
    updateSelected(tabId);
    updatePageUrl(tabId, frameId, pageUrl);
    updatePdfState(tabId, isPdf);
  }
}

function sendSelectionWorkshopRequest(tabId, userConfig, hasSelection) {
  const params = {
    userConfig,
    hasSelection,
    tabId,
    action: MessageAction.SELECTION_WORKSHOP,
    installDate: Number(INSTALL_DATE),
  };
  chrome.tabs.sendMessage(tabId, params, {}, () => {
    browserEnv.checkLogLastError(
      ">> background.sendSelectionWorkshopRequest: Error caught |>"
    );
  });
}

function handleDisplayInlineRequest() {
  getCachedExtensionUserConfig()
    .then((userConfig) => {
      return queryActiveTab("handleDisplayInlineRequest").then((tab) =>
        sendDisplayInlineRequest(tab.id, userConfig)
      );
    })
    .catch(err => swallowError(err, 'handleDisplayInlineRequest-getCachedExtensionUserConfig'));
}

function sendDisplayInlineRequest(tabId, userConfig) {
  const params = {
    action: MessageAction.DISPLAY_INLINE,
    tabId,
    userConfig,
  };
  chrome.tabs.sendMessage(tabId, params, {}, () => {
    browserEnv.checkLogLastError(
      ">> background.sendDisplayInlineRequest: Error caught |>"
    );
  });
}

function sendRefreshMessageToFrame(tabId, frameId, popupInitiated) {
  return new Promise((resolve) => {
    const params = {
      action: MessageAction.REFRESH,
      popupInitiated,
    };

    chrome.tabs.sendMessage(tabId, params, { frameId }, (defs) => {
      if (browserEnv.hasRuntimeError()) {
        browserEnv.checkLogLastError(
          ">> background.sendRefreshMessageToFrame: Error caught |>"
        );
        killFrame(tabId, frameId);
      } else {
        updateWithTables(tabId, frameId, defs);
      }
      resolve();
    });
  });
}

// NOTE(gmike): Doesn't reject.
function sendMessageToFrame(tabId, frameId, params) {
  frameId = Number(frameId);

  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, params, { frameId }, (response) => {
      if (browserEnv.hasRuntimeError()) {
        browserEnv.checkLogLastError(
          ">> background.sendMessageToFrame: Error caught |>"
        );
        killFrame(tabId, frameId);
      } else {
        resolve({ tabId, frameId, response });
      }
    });
  });
}

function triggerRefresh(tabId, popupInitiated) {
  console.log(`background.triggerRefresh (tabId = ${tabId})`);

  const frames = tabToFrames[tabId] || [];
  return Promise.all(
    frames.map((frameId) =>
      sendRefreshMessageToFrame(tabId, frameId, popupInitiated)
    )
  );
}

function checkCookie(tabId, url) {
  const action = MessageAction.PROMPT_PASTE;

  const newlyCreated = Cookies.get(_TCAP_CONFIG.cookie.tabId);
  if (newlyCreated && newlyCreated == tabId) {
    chrome.tabs.sendMessage(tabId, { action }, {}, (response) => {
      if (browserEnv.hasRuntimeError()) {
        browserEnv.checkLogLastError(
          ">> background.checkCookie: Error caught |>"
        );
      } else if (response && response.alerted) {
        Cookies.remove(_TCAP_CONFIG.cookie.tabId);
      } else {
        // No-op.
      }
    });

    // Clear the cookie regardless in 10 seconds.
    window.setTimeout(() => {
      Cookies.remove(_TCAP_CONFIG.cookie.tabId);
    }, 10 * 1000);
  }

  const o365 = Cookies.get(_TCAP_CONFIG.cookie.o365);
  if (o365 && url && url.includes(".sharepoint.com/")) {
    chrome.tabs.sendMessage(tabId, { action }, {}, (response) => {
      if (browserEnv.hasRuntimeError()) {
        browserEnv.checkLogLastError(
          ">> background.checkCookie: Error caught |>"
        );
      } else if (response && response.alerted) {
        Cookies.remove(_TCAP_CONFIG.cookie.o365);
      } else {
        // No-op.
      }
    });

    // Clear the cookie regardless in 10 seconds.
    window.setTimeout(() => {
      Cookies.remove(_TCAP_CONFIG.cookie.o365);
    }, 10 * 1000);
  }
}

function handleRequestToOpenUrl(request, sendResponse) {
  const { url, outputFormat, enablePastePrompt } = request;
  browserEnv.createTab({ selected: true, url }).then((tab) => {
    if (enablePastePrompt) {
      if (outputFormat === OutputFormat.GOOG) {
        Cookies.set(_TCAP_CONFIG.cookie.tabId, tab.id, {
          expires: 2,
          path: chrome.extension.getURL("/"),
        });
      } else if (outputFormat === OutputFormat.OFFICE365) {
        Cookies.set(_TCAP_CONFIG.cookie.o365, tab.id, {
          expires: 2,
          path: chrome.extension.getURL("/"),
        });
      } else {
        // No-op.
      }
    }
  });
  sendResponse({});
}

function handleRequestWithAction(request, sender, sendResponse) {
  const { tab, frameId } = sender;
  const action = request.action;

  if (action === MessageAction.PUBLISH_TABLE) {
    const api = new GMikeAPI();

    return api
      .persistPublicTable(request.publicTable)
      .then((publicTable) => sendResponse(publicTable))
      .catch((err) => sendResponse({ err }));
  }

  if (action === MessageAction.SHEET_SYNC_CREATE) {
    const instanceId = request.instanceId;
    if (gsheetMap[instanceId]) {
      return sendResponse({created: false, sheet: gsheetMap[instanceId]});
    }
    return authWrapper
        .getGoogleToken()
        .then(accessToken => sheetsSync.createSheet(accessToken, request.title))
        .then(({id, url}) => {
          gsheetMap[instanceId] = {id, url};
          return browserEnv.createTab({ selected: true, url });
        })
        .then(() => sendResponse({sheet: gsheetMap[instanceId], created: true}))
        .catch((err) => sendResponse({ err }));
  }

  if (action === MessageAction.SHEET_SYNC_WRITE) {
    const instanceId = request.instanceId;
    if (!gsheetMap[instanceId]) {
      return sendResponse({err: new Error("Missing Google Sheet")});
    }
    if (gsheetMap[instanceId].id !== request.sheetId) {
      return sendResponse({err: new Error("Google Sheet ID mismatch")});
    }

    const sheet = gsheetMap[instanceId];
    return authWrapper
        .getGoogleToken()
        .then(accessToken => sheetsSync.writeToSheet(accessToken, sheet, request.dataArray))
        .then(() => sendResponse({success: true}))
        .catch((err) => sendResponse({ err }));
  }

  switch (action) {
    case MessageAction.EDIT_TABLE:
      return saveTableLocally(request.publicTable)
        .then(() => sendResponse({ url: "edit.html" }))
        .catch((err) => sendResponse({ err }));

    case MessageAction.SCREENSHOT_VISIBLE_TAB:
      return performTabScreenshot(tab.id)
        .then((dataUrl) => sendResponse({ dataUrl }))
        .catch((err) => sendResponse({ err }));

    case MessageAction.PAGING_DATA_UPDATE:
      handlePagingDataUpdate(tab.id, frameId, request);
      break;

    case MessageAction.PAGING_LISTEN_START:
      handlePagingListenStart(tab.id, frameId, request);
      break;

    case MessageAction.PAGING_LISTEN_STOP:
      handlePagingListenStop(tab.id, frameId);
      break;

    case MessageAction.AUTO_PAGING_UPDATE:
      handleAutoPagingUpdate(tab.id, frameId, request.autoPageTable);
      break;

    // Used by PagingListener
    case MessageAction.COPY_STRING:
      Clipboard.copy(request.stringData);
      break;

    case MessageAction.COPY_TABLE_STRING:
      _tcLogRequestAction(request, syncGetCachedExtensionUserConfig);
      Clipboard.copy(request.tableString);
      break;

    default:
      const errorMessage = `chrome.extension.onRequest::Fall-through (${action})`;
      console.log(errorMessage, request);
      return sendResponse({ err: new Error(errorMessage) });
  }

  return sendResponse({});
}

//// PAGING

function handlePagingListenStart(tabId, frameId, request) {
  createTabFrameEntryIfDNE(tabId, frameId, tabToPagingState);
  tabToPagingState[tabId][frameId] = {
    ...request,
    frameId,
    paging: true,
  };
}

function handlePagingDataUpdate(tabId, frameId, { data, count }) {
  if (!tabToPagingState[tabId] || !tabToPagingState[tabId][frameId]) {
    return;
  }
  tabToPagingState[tabId][frameId].data = data;
  tabToPagingState[tabId][frameId].count = count;
}

function handlePagingListenStop(tabId, frameId) {
  try {
    tabToPagingState[tabId] = null;
    delete tabToPagingState[tabId];
  } catch (err) {
    // No-op.
  }
}

function handleAutoPagingUpdate(tabId, frameId, autoPageTable) {
  try {
    tabToPagingState[tabId][frameId].autoPageTable = autoPageTable;
  } catch (err) {
    // No-op.
  }
}

function checkHistoryStatePaging(tabId, frameId) {
  if (!tabToPagingState[tabId] || !tabToPagingState[tabId][frameId]) {
    return;
  }
  const params = {
    action: MessageAction.PAGING_CONTINUATION_PAGE_REFRESH,
  };
  sendMessageToFrame(tabId, frameId, params);
}

function checkPaging(tabId) {
  if (tabToPagingState.hasOwnProperty(tabId)) {
    const continuationKey = `continue-paging-Tab:${tabId}`;
    getCachedExtensionUserConfig()
      .then((userConfig) => {
        Object.keys(tabToPagingState[tabId]).forEach((frameId) => {
          console.log(
            `chrome.extension.checkPaging (${continuationKey}), Frame: ${frameId}`
          );
          const params = {
            ...tabToPagingState[tabId][frameId],
            userConfig,
            continuationKey,
            action: MessageAction.PAGING_CONTINUATION,
          };
          sendMessageToFrame(tabId, frameId, params);
        });
      })
      .catch(err => swallowError(err, 'checkPaging-getCachedExtensionUserConfig'));
  }
}

//// TABLE EDITING

function saveTableLocally(publicTable) {
  activeEditableTable = publicTable;
  browserEnv.createTab({ url: "/table-edit.html" });
  return Promise.resolve();
}

function getLocalTableForEdit() {
  return Promise.resolve(activeEditableTable);
}

//// TABLE CAPTURE CLOUD

function saveTableForCloud(repro) {
  activeCloudRepro = repro;
  browserEnv.createTab({ url: "/cloud.html" });
  return Promise.resolve();
}

function getLocalTableForCloud() {
  return Promise.resolve(activeCloudRepro);
}

function updateStarredActionContextMenus(userConfig, tab) {
  getExtensionActivityLogData(browserEnv)
      .then(logData => {
        removeAllStarredActionContextMenus();

        if (!logData) {
          return;
        }

        Object
            .values(logData)
            .forEach(entry => {
              if (entry && entry.url === tab.url) {
                Object
                    .values(entry.elements)
                    .filter(pageElementEntry => pageElementEntry.starred)
                    .forEach(pageElementEntry => {
                      if (pageElementEntry.repros && pageElementEntry.repros.length) {
                        const latestRepro = pageElementEntry.repros[pageElementEntry.repros.length - 1];
                        const menuId = chrome.contextMenus.create({
                          title: chrome.i18n.getMessage("contextMenuActivity", [
                            summarizeRepro(latestRepro),
                            pageElementEntry.name,
                          ]),
                          contexts: ["page"],
                          onclick: (info, tab) => sendReproRequest(tab.id, userConfig, latestRepro),
                        });
                        activityContextMenuMap[latestRepro.timestamp] = menuId;
                      }
                    });
              }
            });
      })
      .catch(err => swallowError(err, 'updateStarredActionContextMenus'));
}

function removeAllStarredActionContextMenus() {
  Object
    .values(activityContextMenuMap)
    .forEach(menuId => {
      chrome.contextMenus.remove(menuId, () => {
        browserEnv.checkLogLastError(
          ">> background.removeAllStarredActionContextMenus: Error caught |>"
        );
      });
    });
  activityContextMenuMap = {};
}

function sendReproRequest(tabId, userConfig, repro) {
  const params = {
    userConfig,
    repro,
    tabId,
    action: MessageAction.REPRO_PERFORM,
  };
  chrome.tabs.sendMessage(tabId, params, {}, (resp) => {
    browserEnv.checkLogLastError(
      ">> background.sendReproRequest: Error caught |>"
    );
  });
}

//// RECIPES

function sendWorkshopRecipeRequest(tabId, userConfig, recipe) {
  const params = {
    userConfig,
    recipe,
    tabId,
    action: MessageAction.SELECTION_WORKSHOP_RECIPE,
  };
  chrome.tabs.sendMessage(tabId, params, {}, () => {
    browserEnv.checkLogLastError(
      ">> background.sendWorkshopRecipeRequest: Error caught |>"
    );
  });
}

function updateRecipeContextMenus(userConfig, tab) {
  userConfig.recipes
    .filter((r) => r.status == "active" && !r.disabled)
    .forEach((recipe) => {
      if (recipeContextMenuMap[recipe.id]) {
        chrome.contextMenus.remove(recipeContextMenuMap[recipe.id], () => {
          browserEnv.checkLogLastError(
            ">> background.updateRecipeContextMenus: Error caught |>"
          );
        });
      }

      if (tab.url.match(new RegExp(recipe.urlRegex))) {
        const menuId = chrome.contextMenus.create({
          title: chrome.i18n.getMessage("contextMenuRecipe", [recipe.name]),
          contexts: ["page"],
          onclick: (info, tab) => {
            sendWorkshopRecipeRequest(tab.id, userConfig, recipe);
          },
        });
        recipeContextMenuMap[recipe.id] = menuId;
      }
    });
}

function checkMatchingRecipesAndStarred(tabId) {
  if (USER_CONFIG) {
    queryTab(tabId)
      .then((tab) => {
        if (USER_CONFIG.recipes && USER_CONFIG.paidPro) {
          updateRecipeContextMenus(USER_CONFIG, tab);
        }
        updateStarredActionContextMenus(USER_CONFIG, tab);
      })
      .catch(err => swallowError(err, 'checkMatchingRecipesAndStarred-queryTab'));
  }
}

function isSelectedTabReadyForMessages() {
  return (
    selectedId && tabToFrames[selectedId] && tabToFrames[selectedId].length
  );
}

function removeInstallMenuPrompt() {
  if (contextMenuMap.INSTALL) {
    chrome.contextMenus.remove(contextMenuMap.INSTALL, () => {
      browserEnv.checkLogLastError(
        ">> background.updateContextMenus: Error caught |>"
      );
    });
    contextMenuMap.INSTALL = null;
  }
}

function displayInstallMenuPrompt() {
  contextMenuMap.INSTALL = chrome.contextMenus.create({
    title: chrome.i18n.getMessage("contextMenuRefreshNeeded"),
    contexts: ["page", "selection"],
    onclick: (info, tab) => {},
  });
}

function removeFunctionalContextMenuItems() {
  if (contextMenuMap.FUNCTION) {
    contextMenuMap.FUNCTION.forEach((menuId) => {
      chrome.contextMenus.remove(menuId, () => {
        browserEnv.checkLogLastError(
          ">> background.updateContextMenus: Error caught |>"
        );
      });
    });
  }
}

function displayFunctionalContextMenuItems() {
  removeFunctionalContextMenuItems();

  contextMenuMap.FUNCTION = [];
  contextMenuMap.FUNCTION.push(
    chrome.contextMenus.create({
      title: chrome.i18n.getMessage("contextMenuLaunchWorkshop"),
      contexts: ["page"],
      onclick: (info, tab) => {
        getCachedExtensionUserConfig()
          .then((userConfig) =>
            sendSelectionWorkshopRequest(tab.id, userConfig, false)
          )
          .catch(err => swallowError(err, 'contextMenuLaunchWorkshop-getCachedExtensionUserConfig'));
      },
    })
  );

  contextMenuMap.FUNCTION.push(
    chrome.contextMenus.create({
      title: chrome.i18n.getMessage("contextMenuLaunchWorkshopForSelection"),
      contexts: ["selection"],
      onclick: (info, tab) => {
        getCachedExtensionUserConfig()
          .then((userConfig) =>
            sendSelectionWorkshopRequest(tab.id, userConfig, true)
          )
          .catch(err => swallowError(err, 'contextMenuLaunchWorkshopForSelection-getCachedExtensionUserConfig'));
      },
    })
  );

  contextMenuMap.FUNCTION.push(
    chrome.contextMenus.create({
      title: chrome.i18n.getMessage("contextMenuLaunchWorkshopForElement"),
      contexts: ["link"],
      onclick: (info, tab) => {
        getCachedExtensionUserConfig()
          .then((userConfig) =>
            sendSelectionWorkshopRequest(tab.id, userConfig, false)
          )
          .catch(err => swallowError(err, 'contextMenuLaunchWorkshopForElement-getCachedExtensionUserConfig'));
      },
    })
  );

  contextMenuMap.FUNCTION.push(
    chrome.contextMenus.create({
      title: chrome.i18n.getMessage("contextMenuDisplayInline"),
      contexts: ["page"],
      onclick: (info, tab) => {
        getCachedExtensionUserConfig()
          .then((userConfig) => sendDisplayInlineRequest(tab.id, userConfig))
          .catch(err => swallowError(err, 'contextMenuDisplayInline-getCachedExtensionUserConfig'));
      },
    })
  );
}

function updateContextMenus() {
  if (isActiveTabPdfPage()) {
    updateContextMenusForPdf();
    return;
  }

  removeInstallMenuPrompt();
  if (isSelectedTabReadyForMessages()) {
    displayFunctionalContextMenuItems();
  } else {
    displayInstallMenuPrompt();
  }
}

function updateContextMenusForPdf() {
  removeInstallMenuPrompt();
  removeFunctionalContextMenuItems();
  removeAllStarredActionContextMenus();
}

//// BROWSER

chrome.commands.onCommand.addListener((command) => {
  if (command === "display-inline-table-capture") {
    handleDisplayInlineRequest();
  }
});

chrome.extension.onMessage.addListener((request, sender, sendResponse) => {
  const action = request && request.action;
  const tabId = sender && sender.tab && sender.tab.id;
  const frameId = sender && sender.frameId;

  console.log(
    `chrome.extension.onMessage (action = ${action}, tabId = ${tabId}, frameId = ${frameId})`
  );

  if (tabId === undefined) {
    const errorMessage = `chrome.extension.onMessage::Error: tabId === undefined`;
    console.log(errorMessage, request);
    // NOTE(gmike, 2021-10-01): No longer throwing
    // throw new Error(errorMessage);
    sendResponse({});
    return;
  }

  if (!tabToFrames[tabId]) {
    tabToFrames[tabId] = [];
  }

  switch (action) {
    case MessageAction.LOG_EVENT:
      new ActivityLogger().logEvent(request.event, request.context);
      break;

    case MessageAction.HELLO:
      tabToFrames[tabId].push(sender.frameId);
      updateWithTables(tabId, frameId, request);
      checkPaging(tabId);
      break;

    default:
      const errorMessage = `chrome.extension.onMessage::Fall-through`;
      console.log(errorMessage, request);
      throw new Error(errorMessage);
  }

  sendResponse({});
});

chrome.extension.onRequest.addListener((request, sender, sendResponse) => {
  if (request && request.url) {
    return handleRequestToOpenUrl(request, sendResponse);
  }

  if (request && request.action) {
    return handleRequestWithAction(request, sender, sendResponse);
  }

  sendResponse({});
});

const INSTALL_DATE =
  Cookies.get(_TCAP_CONFIG.cookie.install) || _tcGetNowDateKey();
chrome.runtime.setUninstallURL(
  `https://www.georgemike.com/tablecapture/uninstall/?dun=${INSTALL_DATE}&ver=${_TCAP_CONFIG.versionText}`
);

chrome.runtime.onInstalled.addListener((details) => {
  if (details && details.reason === "install") {
    browserEnv.createTab({ url: "/options.html?install=1" });

    // Set the install date.
    Cookies.set(_TCAP_CONFIG.cookie.install, INSTALL_DATE, {
      path: chrome.extension.getURL("/"),
    });
  }
});

chrome.windows.onFocusChanged.addListener(() => {
  const actionContext = "chrome.windows.onFocusChanged";
  queryActiveTab(actionContext)
    .then((tab) => updateSelected(tab.id))
    .catch(err => swallowError(err, actionContext, true));
});
chrome.tabs.onSelectionChanged.addListener((tabId) => updateSelected(tabId));

chrome.webNavigation.onCompleted.addListener(({ frameId, tabId, url }) => {
  console.log(
    `chrome.webNavigation.onCompleted (tabId = ${tabId}, frameId = ${frameId})`
  );

  // NOTE(gmike): This happens for tabs that have existed before extension install.
  if (selectedId == null) {
    updateSelected(tabId);
  }

  checkCookie(tabId, url);
  // NOTE(gmike): Used to perform this here as of v9.9.30
  // It was relocated to on MessageAction.HELLO because that's when the TableManager is ready.
  // checkPaging(tabId);
  sendRefreshMessageToFrame(tabId, frameId, false);
});

chrome.webNavigation.onHistoryStateUpdated.addListener(
  ({ frameId, tabId, url }) => {
    console.log(
      `chrome.webNavigation.onHistoryStateUpdated (tabId = ${tabId}, frameId = ${frameId}, url = ${url})`
    );

    // NOTE(gmike): Added in 9.9.33.
    checkHistoryStatePaging(tabId, frameId);
  }
);

updateContextMenus();
