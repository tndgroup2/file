
class AutoPager {
  constructor() {
    this.listening_ = false;
    this.on_ = false;
    this.clickedElementsTimeout_ = null;
    this.clickedElements_ = [];
    this.onOnAction_ = null;
  }

  isOn() {
    return this.on_;
  }

  isOnIsh() {
    return this.on_ || (this.clickedElements_ && this.clickedElements_.length && !!this.clickedElementsTimeout_);
  }

  turnOff() {
    this.on_ = false;
    this.listening_ = false;
    this.clickedElements_ = [];
    if (this.clickedElementsTimeout_) {
      window.clearTimeout(this.clickedElementsTimeout_);
      this.clickedElementsTimeout_ = null;
    }
  }

  beginListeningForAdvance() {
    this.listening_ = true;

    Array
        .from(document.querySelectorAll('*'))
        .forEach(el => this.waitForClick_(el));
  }

  waitForClick_(el) {
    // TODO(gmike): We may want to save these for removal later.
    const fn = this.handleClick_.bind(this, el);
    el.addEventListener('mousedown', fn);
  }

  handleClick_(el, e) {
    if (this.listening_) {
      if (isNodeWorkshopChild(el) || el.nodeName === 'HTML' || el.nodeName === 'BODY') {
        // No-op.
      } else {
        if (this.clickedElementsTimeout_) {
          window.clearTimeout(this.clickedElementsTimeout_);
        }
        this.clickedElements_.push(el);
        this.clickedElementsTimeout_ = window.setTimeout(this.handleClickedElements_.bind(this), 50);
      }
    }
    return true;
  }

  handleClickedElements_() {
    if (this.clickedElements_ && this.clickedElements_.length) {
      const el = this.clickedElements_.shift();
      this.pagingEl_ = el;
      this.on_ = true;
      
      if (this.onOnAction_) {
        this.onOnAction_();
        this.onOnAction_ = null;
      }
    }
    this.clickedElementsTimeout_ = null;
  }

  advanceEventually() {
    if (this.advanceTimeout_) {
      window.clearTimeout(this.advanceTimeout_);
    }

    this.advanceTimeout_ = window.setTimeout(() => {
      this.advanceTimeout_ = null;

      if (this.on_) {
        this.advance();
      } else {
        this.onOnAction_ = this.advance.bind(this);
      }
    }, _TCAP_CONFIG.dynPageInterval);
  }

  advance() {
    if (this.listening_) {
      this.listening_ = false;
    }

    try {
      if (this.pagingEl_ && !this.pagingEl_.isConnected) {
        this.maybeUpdatePagingEl_();
      }

      if (this.pagingEl_) {
        _tcDoClick(this.pagingEl_);
      }
    } catch (err) {
      // No-op.
    }
  }

  // Attempts to find a connected paging element.
  maybeUpdatePagingEl_(){
    if (!this.pagingEl_) {
      return;
    }
    if (this.pagingEl_.id) {
      const newEl = document.querySelector(`#${this.pagingEl_.id}`);
      if (newEl) {
        this.pagingEl_ = newEl;
        return;
      }
    }
    if (this.pagingEl_.className) {
      const newEls = document.querySelectorAll("." + targetNode.className.split(' ').join('.'));
      if (newEls && newEls.length === 1) {
        this.pagingEl_ = newEls[0];
        return;
      }
    }
  }
}
