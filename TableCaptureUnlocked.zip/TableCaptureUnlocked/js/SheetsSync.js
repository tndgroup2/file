
function onGAPILoad() {
  gapi.client.init({
    apiKey: _TC_GSHEETS_API_KEY,
    discoveryDocs: ["https://sheets.googleapis.com/$discovery/rest?version=v4"],
  }).then(function () {}, function(error) {
    console.log('onGAPILoad::error', error)
  });
}

function addGapiToPage() {
  const head = document.getElementsByTagName('head')[0];
  const script = document.createElement('script');
  script.type = 'text/javascript';
  script.src = "https://apis.google.com/js/client.js?onload=onGAPILoad";
  head.appendChild(script);
}

addGapiToPage();

////

function buildGSheetUrl(id) {
  return `https://docs.google.com/spreadsheets/d/${id}/edit`;
}

function getSheetRange(spreadsheetId, range) {
  return gapi.client.sheets.spreadsheets.values.get({spreadsheetId, range})
}

function createGSheet(title) {
  return new Promise((resolve, reject) => {
    gapi.client.sheets.spreadsheets
        .create({
          properties: { title }
        })
        .then((response) => {
          const id = response.result.spreadsheetId;
          const url = buildGSheetUrl(id);
          return resolve({id, url});
        })
        .catch(reject); 
  });
}

function writeToSheetPlease(spreadsheetId, sheetName, values) {
  // let range = sheetName + "!A1:H1";
  const range = sheetName;
  const params = {
    spreadsheetId,
    range,
    valueInputOption: 'USER_ENTERED'
  }
  const reqBody = {
    range,
    majorDimension: "ROWS",
    values,
  }
  return gapi.client.sheets.spreadsheets.values.update(params, reqBody);
}

function writeToSheet(spreadsheetId, range, values) {
  const resource = {values};
  return gapi.client.sheets.spreadsheets.values
      .batchUpdate({
        spreadsheetId,
        range,
        resource,
        valueInputOption: 'USER_ENTERED',
        includeValuesInResponse: false,
      });
}

function appendToSheet(spreadsheetId, range, values) {
  const resource = {values};
  return gapi.client.sheets.spreadsheets.values
      .append({
        spreadsheetId,
        range,
        resource,
        valueInputOption: 'USER_ENTERED',
      });
}

////

class SheetsSync {
  constructor() {

  }

  setAccessToken_(accessToken) {
    gapi.auth.setToken({
      access_token: accessToken,
    });
    return Promise.resolve();
  }

  getSheetRowCount(accessToken, spreadsheetId, range) {
    return this
        .setAccessToken_(accessToken)
        .then(() => getSheetRange(spreadsheetId, range))
        .then(response =>response.result.values.length);
  }

  createSheet(accessToken, title) {
    return this
        .setAccessToken_(accessToken)
        .then(() => createGSheet(title));
  }

  writeToSheet(accessToken, sheet, dataArray) {
    return this
        .setAccessToken_(accessToken)
        .then(() => writeToSheetPlease(sheet.id, "Sheet1", dataArray));
        // .then(() => writeToSheet(sheet.id, "Sheet1", dataArray));
  }
}
