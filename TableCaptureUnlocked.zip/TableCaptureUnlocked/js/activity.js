
document.addEventListener('DOMContentLoaded', () => {
  new OptionsChrome('activity');
  new FavoritesManager().initialize();
});
