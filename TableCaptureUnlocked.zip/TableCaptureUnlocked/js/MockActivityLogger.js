
class ActivityLogger {
  constructor() {}
  logPage() {}
  logEvent(event, context) {}
}
