
const createAlertPane = (message, alertLevel='warning', dismissable=false) => {
  const pane = document.createElement('div');
  pane.innerText = message;
  pane.className = `alert alert-${alertLevel}`;
  if (dismissable) {
    pane.addEventListener('click', () => pane.remove());
  }
  return pane;
};

const createAlertPaneWithHTML = (html, alertLevel='warning', dismissable=false) => {
  const pane = createAlertPane('', alertLevel, dismissable);
  pane.innerHTML = html;
  return pane;
};
