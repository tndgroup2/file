
class FavoritesManager {
  constructor () {
    this.activityLogger_ = new ActivityLogger();
    this.browserEnv_ = new BrowserEnv();

    getExtensionUserConfig()
      .then(userConfig => {
        this.userConfig_ = userConfig;
      })
      .catch(this.handleError_.bind(this));
  }

  initialize () {
    getExtensionActivityLogData(this.browserEnv_)
        .then(logData => {
          if (logData) {
            this.renderActivity_(logData);
          } else {
            this.renderNoActivityMode_();
          }
        })
        .catch(this.handleError_.bind(this));

    document
        .querySelector('.btn-clear-activity')
        .addEventListener('click', this.clearHistory_.bind(this));
  }

  clearHistory_ () {
    this.browserEnv_
        .getLocalStorageApi()
        .removeP(_TCAP_CONFIG.logKey);
    window.location.reload();
  }

  renderNoActivityMode_ () {
    document.querySelector('.alert-no-data').classList.remove('hidden');
  }

  renderActivity_ (logData) {
    if (!logData || Object.keys(logData).length == 0) {
      return this.renderNoActivityMode_();
    }

    const activityList = document.querySelector('.activity-wrapper ul');
    activityList.innerHTML = '';
    Object
        .values(logData)
        .forEach(entry => {
          const url = entry.url;
          const hasValidUrl = url && !url.includes('file://');

          if (entry.actionCount && entry.actionCount > 0 && hasValidUrl) {
            if (entry.elements && Object.values(entry.elements).length > 0) {
              activityList.appendChild(this.renderEntrySummary_(entry));
            }
          }
        });
  }

  renderPageElement_ (logItem, pageEntry) {
    const name = pageEntry.name;
    const starred = pageEntry.starred;
    const hasRepros = pageEntry.repros && pageEntry.repros.length;
    const lastActionSummary = hasRepros
      ? `<span class="last-action-summary">${summarizeLatestRepro(pageEntry.repros)}</span>`
      : "";

    const pageElement = document.createElement('div');
    pageElement.classList.add('page-element');
    pageElement.innerHTML = `
      <div class="header">
        <div class="left-side">
          <span
              class="fave-toggle-btn glyphicon ${starred ? 'glyphicon-star' : 'glyphicon-star-empty'}"
              title="${starred ? 'Remove from favorites' : 'Add to favorites'}"></span>
          <span>${name}</span>
          ${lastActionSummary}
        </div>
        <div class="actions">
          <button class="btn btn-default btn-image cloud-btn" title="Table Capture + Cloud">
            <img src="/images/icon.cloud.128.png" />
          </button>
          <button class="btn btn-primary fetch-btn">Get data</button>
          <button class="btn btn-danger delete-entry-btn">
            <span class="glyphicon glyphicon-trash" title="Delete"></span>
          </button>
        </div>
      </div>
    `;
    pageElement
        .querySelector('.fetch-btn')
        .addEventListener('click', () => {
          this.fetchData_(logItem, pageEntry);
        });
    pageElement
        .querySelector('.cloud-btn')
        .addEventListener('click', () => {
          this.cloudOperate_(logItem, pageEntry);
        });
    pageElement
        .querySelector('.delete-entry-btn')
        .addEventListener('click', () => {
          this.deleteEntry_(logItem, pageEntry);
        });
    pageElement
        .querySelector('.fave-toggle-btn')
        .addEventListener('click', () => {
          this.toggleFave_(logItem, pageEntry);
        });
    pageEntry.element = pageElement;
    return pageElement;
  }

  renderEntrySummary_ (logItem) {
    const separator = () => {
      const span = document.createElement('span');
      span.innerHTML = '&nbsp;&middot;&nbsp;';
      return span;
    };

    // Data
    const title = logItem.title || logItem.url;

    const titleElement = document.createElement('div');
    titleElement.classList.add('title');
    titleElement.innerText = title;

    const meta = document.createElement('div');

    const viewCount = document.createElement('span');
    viewCount.innerText = `Actions: ${logItem.actionCount}`;

    const link = document.createElement('a');
    link.href = logItem.url;
    link.innerText = 'Visit page';
    link.target = '_blank';

    meta.appendChild(link);
    meta.appendChild(separator());
    meta.appendChild(viewCount);

    const alertsElement = document.createElement('div');
    alertsElement.className = 'error-wrapper local-error-wrapper';

    const pageElementsWrapper = document.createElement('div');
    pageElementsWrapper.classList.add('page-elements');

    Object
        .values(logItem.elements)
        .sort((a, b) => {
          return b.actionCount - a.actionCount;
        })
        .forEach(pageElementEntry => {
          pageElementsWrapper.appendChild(this.renderPageElement_(logItem, pageElementEntry));
        });

    const element = document.createElement('li');
    element.appendChild(titleElement);
    element.appendChild(meta);
    element.appendChild(pageElementsWrapper);
    element.appendChild(alertsElement);

    return element;
  }

  deleteEntry_(logItem, pageEntry) {
    this.activityLogger_.logEvent('FavoritesManager.deleteEntry_');
    getExtensionActivityLogData(this.browserEnv_)
        .then(logData => {
          delete logData[logItem.url].elements[pageEntry.key];
          return this.browserEnv_
              .getLocalStorageApi()
              .setP({[_TCAP_CONFIG.logKey]: logData})
              .then(() => this.renderActivity_(logData));
        })
        .catch(err => {
          this.handleError_(err, this.getErrorWrapperFromPageElement_(pageEntry.element));
        });
  }

  toggleFave_(logItem, pageEntry) {
    this.activityLogger_.logEvent('FavoritesManager.toggleFave_');

    getExtensionActivityLogData(this.browserEnv_)
        .then(logData => {
          const entry = logData[logItem.url].elements[pageEntry.key];
          entry.starred = !entry.starred;
          return this.browserEnv_
              .getLocalStorageApi()
              .setP({[_TCAP_CONFIG.logKey]: logData})
              .then(() => this.renderActivity_(logData));
        })
        .catch(err => {
          this.handleError_(err, this.getErrorWrapperFromPageElement_(pageEntry.element));
        });
  }

  cloudOperate_(logItem, {repros}) {
    if (repros && repros.length) {
      return chrome.extension.getBackgroundPage().saveTableForCloud(repros[repros.length - 1]);
    }
  }

  fetchData_ (logItem, pageEntry) {
    if (pageEntry.paged) {
      this.activityLogger_.logEvent('FavoritesManager.fetchData_.paged');
      return this.handleError_(
          new Error("Multi-page tables cannot be extracted at this time."),
          this.getErrorWrapperFromPageElement_(pageEntry.element));
    }

    this.activityLogger_.logEvent('FavoritesManager.fetchData_');

    fetch(logItem.url)
      .then(response => {
        if (response.status >= 400 && response.status < 600) {
          throw new Error(`Unable to fetch data: ${logItem.url}`);
        }
        return response.text();
      })
      .then(data => this.extractTableFromRequestData(this.userConfig_, data, pageEntry))
      .then(tableNode => {
        const tableWrapper = new TableWrapper(tableNode, logItem.url, null, this.userConfig_);
        pageEntry.tableWrapper = tableWrapper;

        const params = {
          action: MessageAction.EDIT_TABLE,
          publicTable: {
            title: logItem.title,
            pageTitle: logItem.title,
            sourceUrl: logItem.url,
            pages: 0,
            dynamic: false,
            paged: false,
            tableDef: tableWrapper.toJSON(),
            tableDataArray: tableWrapper.getAsArrays(),
          }
        };
        return new BrowserEnv().sendMessage(params);
      })
      .catch(err => {
        this.handleError_(err, this.getErrorWrapperFromPageElement_(pageEntry.element));
      });
  }

  getErrorWrapperFromPageElement_(pageElement) {
    return pageElement
        .parentElement
        .parentElement
        .querySelector('.error-wrapper');
  }

  extractTableFromRequestData(config, htmlContent, {index, pathTo}) {
    const doc = _tcCreateDocumentFromHTMLContent(htmlContent);

    if (pathTo) {
      return this.extractTableFromDocViaPath_(doc, pathTo);
    }

    if (index !== undefined) {
      return this.extractTableFromDocViaIndex_(doc, index);
    }

    throw new Error(`Unable to fetch data: Unable to locate element in response.`);
  }

  extractTableFromDocViaIndex_(doc, index) {
    const table = doc
        .querySelector('body')
        .querySelectorAll('table')[index];
    if (!table) {
      throw new Error(`Unable to fetch data: Unable to locate table in response.`);
    }
    return Promise.resolve(table);
  }

  extractTableFromDocViaPath_(doc, pathTo) {
    const element = _tcGetElementByXpath(pathTo, doc);
    if (!element) {
      throw new Error(`Unable to fetch data: Unable to locate table in response.`);
    }
    return Promise.resolve(element);
  }

  handleError_(err, errorWrapper) {
    console.log('FavoritesManager - error caught during fetchData_', err);

    if (!errorWrapper) {
      errorWrapper = document.querySelector('.global-errors');
    }

    const errorElement = document.createElement('div');
    errorElement.className = 'alert alert-danger';
    errorElement.innerText = err + '';
    errorElement.addEventListener('click', () => {
      errorElement.classList.add('hidden');
    });

    errorWrapper.appendChild(errorElement);
  }
}
