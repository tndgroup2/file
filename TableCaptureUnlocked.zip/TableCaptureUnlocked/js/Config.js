const DEV_PRETEND_PRO = true;
const DEV_PRETEND_CLOUD = false;
const DEV_DEBUG = false;

const EXT_ID = "iebpjdmgckacbodjpijphcplhebcmeop";
const EXT_SLUG = "table-capture";
const LOG_KEY = "tcapLog";
const VERSION_TEXT = "v10.0.25C";
const RELEASE_NAME = "G6 Klay";

////

const _TCAP_EXTRACT_CONFIG_KEYS = [
  "addNewLinesForParagraphs",
  "csvDelimiter",
  "deleteEmptyRows",
  "extractImageSrc",
  "getLinkUrls",
  "ignoreHiddenPageElements",
  "ignoreHiddenTables",
  "ignoreImages",
  "moneyAsNumber",
  "numberAsNumber",
  "numDecimalChar",
  "numThousandChar",
];

const _TCAP_CLOUD_CONFIG_KEYS = [
  "hasCloud",
];

const _TCAP_CLOUD_CONFIG_DEFAULTS = {
  hasCloud: false,
};

const _TCAP_CONFIG_KEYS = [
  ..._TCAP_EXTRACT_CONFIG_KEYS,
  ..._TCAP_CLOUD_CONFIG_KEYS,
  "alwaysAllowColumnify",
  "copyImagesToClipboard",
  "enablePastePrompt",
  "enableRequestSearch",
  "filenameTemplate",
  "renderRowPreview",
  "singleSheetExcelExport",
  "useFrameAgnosticExport",
  // Payments and licensing
  "installDate",
  "licenseCode",
  "paidPro",
  "paidCloud",
  "requiresPaid",
  "userId",
  // Recipes
  "recipes",
];

const _TCAP_CONFIG_DEFAULTS = {
  addNewLinesForParagraphs: false,
  alwaysAllowColumnify: false,
  copyImagesToClipboard: false,
  csvDelimiter: ",",
  deleteEmptyRows: true,
  enablePastePrompt: true,
  enableRequestSearch: false,
  extractImageSrc: false,
  filenameTemplate: "",
  getLinkUrls: false,
  ignoreHiddenPageElements: true,
  ignoreHiddenTables: true,
  ignoreImages: false,
  moneyAsNumber: false,
  numberAsNumber: false,
  numDecimalChar: ".",
  numThousandChar: ",",
  renderRowPreview: true,
  singleSheetExcelExport: false,
  useFrameAgnosticExport: true,
  // Payments and licensing
  installDate: null,
  licenseCode: null,
  paidPro: 0,
  paidCloud: 0,
  requiresPaid: false,
  userId: null,
  // Recipes
  recipes: [],
  //
  ..._TCAP_CLOUD_CONFIG_DEFAULTS,
};

//// API

const BASE_API_URL = "https://georgemike.com/api";

////

const _TCAP_CONFIG = {
  releaseName: RELEASE_NAME,
  versionText: VERSION_TEXT,
  devPretendPro: DEV_PRETEND_PRO,
  devPretendCloud: DEV_PRETEND_CLOUD,
  devDebug: DEV_DEBUG,

  cookie: {
    tabId: "tableCaptureTab",
    install: "tableCaptureInstallTime",
    o365: "tableCaptureO365",
  },

  selectionEventKey: "sel-event",
  selectionAttemptKey: "sel-attempt",

  logKey: LOG_KEY,
  extBase: `chrome-extension://${EXT_ID}`,
  chromeExtBase: "chrome-extension://",

  // API
  api: {
    publishTable: `${BASE_API_URL}/table`,
    cloudSignup: `${BASE_API_URL}/licensing/charge/cloudsignup`,
    auth: `${BASE_API_URL}/licensing/charge/user/auth`,
    cloudLicenses: `${BASE_API_URL}/licensing/charge/user/cloudlicenses`,
    ping: `${BASE_API_URL}/licensing/charge/ping`,
  },

  // LICENSING & PAYMENTS
  paidOnly: false,
  cloudLicenseProducts: ["tablecapturecloud"],
  licenseProduct: "tablecapture",
  adjacentProducts: [
    "edgecapture",
    "foxcapture",
    "tablecapturepro",
    "tablecapturelife",
    "tablecapturecloud",
    "tabletoexcel",
  ],
  cloudLicensePurchaseUrl: "https://georgemike.com/tablecapture/cloud/",
  xLicensePurchaseUrl:
    "https://georgemike.com/licensing?app=dGFibGVjYXB0dXJlcHJv",
  licensePurchaseUrl: "https://georgemike.com/licensing?app=dGFibGVjYXB0dXJlcHJv",
  licenseUrl: `${BASE_API_URL}/licensing/charge`,
  manageLicenseUrl: "https://georgemike.com/licensing/manage?key=",
  manageChromeSubscriptionUrl: "https://payments.google.com/payments/home",

  // Links
  reviewLink: `https://chrome.google.com/webstore/detail/${EXT_SLUG}/${EXT_ID}/reviews`,
  supportMailTo: `mailto:support@georgemike.com?subject=Table%20Capture`,
  newsletterUrl: "http://eepurl.com/dmo_QT",
  newSheetsUrl: "http://spreadsheets.google.com/ccc?new=true",
  surveyUrl: "https://goo.gl/forms/0F5PHkDHut8ZYCmo1",
  roadmapUrl:
    "https://docs.google.com/document/d/10wM8tSyatRIlKGM7bYYBHLbfCZANuO5ewoX2SnC8HMs/edit",
  recipesDocUrl:
    "https://docs.google.com/document/d/1bxJNXozYSA_zld8QVA92QhSP5wUA5BMOC5A5h8HZm5o/edit",

  // Office 365
  office365Link: "https://www.office.com/launch/excel?auth=2",

  reportPageUrl: "https://georgemike.com/tables/report?p=$URL",
  reportErrorUrl: "https://georgemike.com/tables/report?err=$ERROR",

  batchWait: 0.5 * 1000,
  selectionDataFullMaxCols: 8,
  selectionDataMaxCols: 4,
  selectionDataFullMaxRows: 25,
  selectionDataMaxRows: 3,
  minValidNumCells: 3,
  scrollInterval: 0.75 * 1000,
  dynPageInterval: 3 * 1000,
  autoPageWait: 3 * 1000,

  rowIdAttr: "_tc-row-id",

  // CA$H
  maxPagingFreeDate: 20210227,

  // SHEET SYNC
  sheetSyncWriteInterval: 10 * 1000,
};

const _TCAP_COPY_CONST = {
  rowSeparator: "\r\n",
  colSeparator: "\t",
};

const _TC_AD_NETWORK_HOSTNAME = ["googleads.g.doubleclick.net"];
const _TC_AD_NETWORK_PARTIALS = [".doubleclick.net", ".googlesyndication.com"];

// NOTE(gmike): This is mostly documentation
const _TC_OAUTH_IDS = {
  dev: "134705207172-01ga3ne286202p9viqs629i8l6k76327.apps.googleusercontent.com",
  prod: "134705207172-cjqlrudj323jpldsf98sjmfaf2045b05.apps.googleusercontent.com",
};

const _TC_GSHEETS_API_KEY = 'AIzaSyBy8JE30kVReC4DIMyZela8qUpTnSxIz8E';
